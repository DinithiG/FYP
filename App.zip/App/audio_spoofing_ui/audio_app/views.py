from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
import os
import tempfile
import torch
import torchaudio
import librosa
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Use the 'Agg' backend for non-GUI plotting
import matplotlib.pyplot as plt
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
# audio_app/views.py
from django.shortcuts import render
import base64
def home(request):
    return render(request, 'home.html', {'message': 'Welcome to the Audio Spoofing Detection App!'})
# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Define the LCNN model
class LCNN(torch.nn.Module):
    def __init__(self, input_dim=124 + 12 + 7 + 6 + 128, num_classes=1):
        super(LCNN, self).__init__()
        self.features = torch.nn.Sequential(
            torch.nn.Conv1d(input_dim, 64, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(64),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(kernel_size=2),
            torch.nn.Dropout(0.2),
            torch.nn.Conv1d(64, 128, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(128),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(kernel_size=2),
            torch.nn.Dropout(0.2),
            torch.nn.Conv1d(128, 256, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(256),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(kernel_size=2),
            torch.nn.Dropout(0.2),
            torch.nn.Conv1d(256, 512, kernel_size=3, padding=1),
            torch.nn.BatchNorm1d(512),
            torch.nn.ReLU(),
            torch.nn.AdaptiveAvgPool1d(1),
        )
        self.classifier = torch.nn.Sequential(
            torch.nn.Dropout(0.5),
            torch.nn.Linear(512, 256),
            torch.nn.ReLU(),
            torch.nn.Dropout(0.3),
            torch.nn.Linear(256, num_classes),
            torch.nn.Sigmoid(),
        )

    def forward(self, x):
        x = self.features(x)
        x = x.squeeze(-1)
        x = self.classifier(x)
        return x

# Load the trained model
model_path = "/Users/firefly0118/Downloads/App/audio_spoofing_ui/audio_app/models/trained_model_best.pth"
model = LCNN(input_dim=124 + 12 + 7 + 6 + 128).to(device)
model.load_state_dict(torch.load(model_path, map_location=device))
model.eval()

# Helper function to normalize features
def normalize_features(features):
    scaler = StandardScaler()
    features_np = features.numpy().T  # Transpose to shape (time_steps, num_features)
    normalized_features = scaler.fit_transform(features_np)
    return torch.tensor(normalized_features.T, dtype=torch.float32)

# Updated predict_audio function
def predict_audio(audio_file, max_frames=100):
    try:
        # Check if the file exists
        if not os.path.exists(audio_file):
            raise FileNotFoundError("Audio file not found.")
        
        # Load and preprocess the audio file
        waveform, sample_rate = torchaudio.load(audio_file)
        if sample_rate != 16000:
            waveform = torchaudio.functional.resample(waveform, sample_rate, 16000)
        waveform = waveform.squeeze(0)

        # Compute MFCC and additional features
        mfcc_transform = torchaudio.transforms.MFCC(
            sample_rate=16000,
            n_mfcc=40,
            melkwargs={
                "n_fft": 400,
                "hop_length": 160,
                "n_mels": 80,
                "center": True,
                "normalized": True,
            },
        )
        mfcc = mfcc_transform(waveform)
        cqt = librosa.cqt(waveform.numpy(), sr=16000, n_bins=84, bins_per_octave=12, hop_length=160)
        cqt = np.abs(cqt)  # Take the magnitude of the CQT
        cqt = torch.tensor(cqt, dtype=torch.float32)
        chroma = librosa.feature.chroma_stft(S=np.abs(librosa.stft(waveform.numpy())), sr=16000)
        chroma = torch.tensor(chroma, dtype=torch.float32)
        spectral_contrast = librosa.feature.spectral_contrast(S=np.abs(librosa.stft(waveform.numpy())), sr=16000)
        spectral_contrast = torch.tensor(spectral_contrast, dtype=torch.float32)
        tonnetz = librosa.feature.tonnetz(y=waveform.numpy(), sr=16000)
        tonnetz = torch.tensor(tonnetz, dtype=torch.float32)
        mel_spectrogram = librosa.feature.melspectrogram(y=waveform.numpy(), sr=16000, n_fft=400, hop_length=160)
        mel_spectrogram_delta = librosa.feature.delta(mel_spectrogram)
        mel_spectrogram_delta = torch.tensor(mel_spectrogram_delta, dtype=torch.float32)

        # Align all features to MFCC frames using interpolation
        mfcc_frames = mfcc.shape[1]
        features_to_align = [cqt, chroma, spectral_contrast, tonnetz, mel_spectrogram_delta]
        aligned_features = []
        for feature in features_to_align:
            feature_frames = feature.shape[1]
            if feature_frames != mfcc_frames:
                feature = F.interpolate(feature.unsqueeze(0), size=mfcc_frames, mode="linear", align_corners=False).squeeze(0)
            aligned_features.append(feature)

        # Combine all features
        combined_features = torch.cat([mfcc] + aligned_features, dim=0)

        # Normalize features
        combined_features = normalize_features(combined_features)

        # Assume fixed number of segments (e.g., 10 for demonstration)
        num_segments = 10
        frames_per_segment = combined_features.shape[1] // num_segments
        segments = []
        for i in range(num_segments):
            start_frame = i * frames_per_segment
            end_frame = (i + 1) * frames_per_segment if i < num_segments - 1 else combined_features.shape[1]
            segment = combined_features[:, start_frame:end_frame]
            if segment.shape[1] < max_frames:
                padding = max_frames - segment.shape[1]
                segment = torch.nn.functional.pad(segment, (0, padding))
            elif segment.shape[1] > max_frames:
                segment = segment[:, :max_frames]
            segments.append(segment)
        segments = torch.stack(segments).to(device)

        # Make predictions
        with torch.no_grad():
            outputs = model(segments)
            predictions = (outputs.squeeze() >= 0.5).int().cpu().numpy().tolist()

        # Create a list of lists for the output
        output_data = [
            [i + 1, "Genuine" if predictions[i] == 1 else "Spoofed"]
            for i in range(num_segments)
        ]

        # Convert the list of lists to a pandas DataFrame
        df = pd.DataFrame(output_data, columns=["Segment", "Prediction"])

        # Generate waveform plot with predicted segments
        fig, ax = plt.subplots(figsize=(15, 5))
        time_axis = np.arange(0, len(waveform)) / 16000
        plt.plot(time_axis, waveform.numpy(), color='gray', alpha=0.6)
        for i, label in enumerate(predictions):
            start_time = i * (len(waveform) / num_segments) / 16000
            end_time = (i + 1) * (len(waveform) / num_segments) / 16000
            color = 'green' if label == 1 else 'red'
            plt.axvspan(start_time, end_time, alpha=0.3, color=color)
            plt.text((start_time + end_time) / 2, plt.ylim()[1] * 0.95, 
                     "Genuine" if label == 1 else "Spoofed",
                     horizontalalignment='center', verticalalignment='top', fontsize=10, color='white',
                     bbox=dict(facecolor=color, alpha=0.5))
        plt.xlabel("Time (seconds)")
        plt.ylabel("Amplitude")
        plt.title("Model Predictions")
        plt.grid(True, alpha=0.3)

        # Provide recommendation
        if any(pred == 0 for pred in predictions):
            recommendation = "This audio contains spoofed segments."
        else:
            recommendation = "This audio is genuine."

        return df, fig, recommendation

    except Exception as e:
        # Raise the exception to propagate the error
        raise RuntimeError(f"Error in predict_audio: {str(e)}")

from django.http import JsonResponse
import os
import tempfile
import matplotlib.pyplot as plt

# def upload_audio(request):
#     if request.method == 'POST' and request.FILES.get('audio'):
#         # Save the uploaded file to a temporary location
#         audio_file = request.FILES['audio']
#         with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp_file:
#             for chunk in audio_file.chunks():
#                 tmp_file.write(chunk)
#             tmp_file_path = tmp_file.name

#         try:
#             # Process the uploaded audio file
#             df, fig, recommendation = predict_audio(tmp_file_path)

#             # Save the plot to a temporary file
#             plot_path = '/tmp/waveform_plot.png'
#             fig.savefig(plot_path)
#             plt.close(fig)  # Close the figure to free memory

#             # Read the saved image and encode it as Base64
#             with open(plot_path, 'rb') as f:
#                 image_data = f.read()
#             import base64
#             waveform_plot_base64 = base64.b64encode(image_data).decode('utf-8')

#             # Convert the DataFrame to a list of dictionaries for JSON serialization
#             segment_results = df.to_dict(orient='records')

#             # Return the response as JSON
#             return JsonResponse({
#                 "plot": waveform_plot_base64,
#                 "segments": segment_results,
#                 "recommendation": recommendation
#             })

#         except Exception as e:
#             return JsonResponse({"error": f"Prediction failed: {str(e)}"}, status=400)

#         finally:
#             # Clean up the temporary file
#             os.unlink(tmp_file_path)

#     # For GET requests, display the upload form
#     return render(request, 'upload.html')

from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
import os
import tempfile
import matplotlib.pyplot as plt
import base64

# Existing predict_audio function remains unchanged...

import base64
from django.http import JsonResponse
import os
import tempfile
import matplotlib.pyplot as plt

import base64

def upload_audio(request):
    if request.method == 'POST' and request.FILES.get('audio'):
        # Save the uploaded file to a temporary location
        audio_file = request.FILES['audio']
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp_file:
            for chunk in audio_file.chunks():
                tmp_file.write(chunk)
            tmp_file_path = tmp_file.name

        try:
            # Process the uploaded audio file
            df, fig, recommendation = predict_audio(tmp_file_path)

            # Encode the waveform plot as Base64
            buffer = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
            plot_path = buffer.name
            fig.savefig(plot_path)
            plt.close(fig)  # Close the figure to free memory

            with open(plot_path, 'rb') as f:
                image_data = f.read()
            waveform_plot_base64 = base64.b64encode(image_data).decode('utf-8')

            # Convert the DataFrame to a list of dictionaries for JSON serialization
            segment_results = df.to_dict(orient='records')

            # Return the response as JSON
            return JsonResponse({
                "plot": waveform_plot_base64,
                "segments": segment_results,
                "recommendation": recommendation
            })

        except Exception as e:
            return JsonResponse({"error": f"Prediction failed: {str(e)}"}, status=400)

        finally:
            # Clean up the temporary files
            os.unlink(tmp_file_path)
            if 'plot_path' in locals() and os.path.exists(plot_path):
                os.unlink(plot_path)

    # For GET requests, display the upload form
    return render(request, 'upload.html')


def results_view(request):
    # Retrieve results from the session
    segment_results = request.session.get('segment_results', [])
    waveform_plot_base64 = request.session.get('waveform_plot_base64', '')
    recommendation = request.session.get('recommendation', '')

    # Clear the session data after retrieving it
    request.session.pop('segment_results', None)
    request.session.pop('waveform_plot_base64', None)
    request.session.pop('recommendation', None)

    # Render the results page
    return render(request, 'results.html', {
        'segment_results': segment_results,
        'waveform_plot_base64': waveform_plot_base64,
        'recommendation': recommendation
    })